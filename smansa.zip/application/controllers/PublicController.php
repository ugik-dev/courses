<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PublicController extends CI_Controller {

    public function __construct(){
        parent::__construct();
            $this->load->model(array('PublicModel'));
        $this->load->helper(array('DataStructure', 'Validation'));
    
    }
    

  public function search(){
  $this->load->view('PublicPage', [
			'title' => "Search",
      'content' => 'public/Search',
    ]);
  }

  // public function index(){
  //   $this->load->view('PublicPage', [
	// 		'title' => "Home",
  //     'content' => 'public/LandingPage',
  //   ]);
  // }

  public function searchProcess(){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $data = $this->PublicModel->search($this->input->post());
      echo json_encode(array('data' => $data));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }

  
  public function searchEvaluasi(){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $data = $this->PublicModel->searchEvaluasi($this->input->post());
      echo json_encode(array('data' => $data));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }
  public function searchKelas(){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $data = $this->PublicModel->searchDetail($this->input->post());
      echo json_encode(array('data' => $data));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }

  public function searchMapping(){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $fil = $this->input->post();
     
      $data = $this->PublicModel->searchMapping($fil);
      if(!empty( $data[$fil['id_siswa']]['tgl'])){
        $datanew =  $data[$fil['id_siswa']]['tgl'];
      }else{
        $datanew =  "";
      };
      echo json_encode(array('data' => $datanew ));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }

  
  public function searchDetail($id){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $data = $this->PublicModel->search2($id);
     
      $this->load->view('PublicPage', [
        'title' => "Search",
        'content' => 'public/SearchDetail',
        'pageData' => $data [$id]
      ]);
        // echo json_encode(array('data' => $data));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }

  
  public function searchAbsen($id,$map){
    try{
      // $this->SecurityModel->userOnlyGuard(TRUE);
      $data = $this->PublicModel->search2($id);
      $data2 = $this->PublicModel->searchSpekKelas($id);
      $this->load->view('PublicPage', [
        'title' => "Search",
        'content' => 'public/SearchAbsen',
        'pageData' => $data [$id],
        'id_mapping' => $map,
        'dataKelas' => $data2[$map]
      ]);
        // echo json_encode(array('data' => $data));
    } catch (Exception $e) {
      ExceptionHandler::handle($e);
    }
  }

}