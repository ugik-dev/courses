# Remunerasi Unsri
## Get Started
- Download the latest DB Scheme https://goo.gl/5GoiqQ
- Install Composer https://getcomposer.org/ and run `composer install` in /application to install  "PhpSpreadsheet"